#include "pch.h"
#include "MiBiblioteca.h"

int main()
{
    srand(time(nullptr));
    //define el arreglo
    int numeros[N];
    //Ingresa datos al arreglo
    genera_arreglo(numeros);
    //Imprime el arreglo
    imprime_arreglo(numeros);
    //Imprime el mayor
    cout << endl << "EL MAYOR ES: " << halla_el_mayor(numeros);
    cout << endl << "EL MENOR ES: " << hallar_Menor(numeros);
    cout << endl << "La Suma total: " << suma_total(numeros);
    //ordenamiento
    ordena_ascendente(numeros);
    cout << endl << "ARREGLO ORDENADO ASC" << endl;
    imprime_arreglo(numeros);


    system("pause>0");

    return 0;
}
