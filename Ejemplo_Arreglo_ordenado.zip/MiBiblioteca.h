#pragma once
#include "iostream"
using namespace System;
using namespace std;
#define N 20

void genera_arreglo(int arreglo[])
{
    //FORMULA: min + rand()%(max-min +1)
    for (int i = 0; i < N; i++)
    {
        //[40,100)
        arreglo[i] = 40 + rand() % (100 - 40 + 1);
    }
}
void imprime_arreglo(int arreglo[])
{
    cout << endl << "DATOS DEL ARREGLO" << endl;
    for (int i = 0; i < N; i++)
    {
        cout << endl << "Numeros [" << i << "] = " << arreglo[i];
    }
}
int halla_el_mayor(int arreglo[])
{
    int mayor = 40;
    for (int i = 0; i < N; i++)
    {
        if (arreglo[i] > mayor)
        {
            mayor = arreglo[i];
        }
    }

    return mayor;
}
int hallar_Menor(int arreglo[]) {
    int menor = 10000;
    for (int i = 0; i < N; i++)
    {
        if (arreglo[i] < menor)
        {
            menor = arreglo[i];
        }
    }
    
    return menor;
}
int suma_total(int arreglo[]) {
    int suma = 0;
        for (int i = 0; i < N; i++)
        {
            suma += arreglo[i];
        }
        return suma;
}

void ordena_ascendente(int arreglo[])
{
    int aux;
    for (int i=0; i<N; i++)
    {
        for (int k=i+1; k<N; k++)
        {
            if (arreglo[i] > arreglo[k])
            {
                aux = arreglo[i];
                arreglo[i] = arreglo[k];
                arreglo[k] = aux;
            }
        }
    }
}